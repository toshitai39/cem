# -*- coding: utf-8 -*-
"""
Created on Tue May 28 15:54:33 2024

@author: pkumar11
"""
# -*- coding: utf-8 -*-
"""
Created on Tue May 28 15:54:33 2024

@author: pkumar11
"""
import pandas as pd
import numpy as np

def create_static_parameter_result_df(elasticity_parameter_df, dynamic_df, Company_name, scenario):

    static_parameter_result_df = pd.DataFrame(columns=["Attribute", "Scenario", "Value"])
    attribute_value =['Price Elasticity (ε)', 'Market Cost Elasticity (η)', 'Firm Cost Elasticity (ηi)', 'Firm Profit',
                      'Weight - Markov (with no market recovery for the Net Zero 2050 scenario)',
                      'Weight - What-if (with full market recovery for the Net Zero 2050 scenario)',
                      '1 / (1 - ε · (η - 1))', 'ε / (1 - ε · (η - 1))', 'ε · (η - 1) / (1 - ε · (η - 1))', '1 / (ηi - 1)']
    i = 0 
    for item in attribute_value:
        static_parameter_result_df.loc[i] = [item, scenario, np.nan]
        i = i+1
    
    static_parameter_result_df.loc[static_parameter_result_df["Attribute"] == 'Price Elasticity (ε)' , 'Value'] = elasticity_parameter_df.loc[elasticity_parameter_df["Variable"] =='Price_Elasticity',"Value"]
    static_parameter_result_df.loc[static_parameter_result_df["Attribute"] == 'Market Cost Elasticity (η)' , 'Value'] = elasticity_parameter_df.loc[elasticity_parameter_df["Variable"] =='Market_Cost_Elasticity',"Value"]
    static_parameter_result_df.loc[static_parameter_result_df["Attribute"] == 'Firm Cost Elasticity (ηi)' , 'Value'] = elasticity_parameter_df.loc[elasticity_parameter_df["Variable"] =='Firm_Cost_Elasticity',"Value"]
    static_parameter_result_df.iat[3,2] = elasticity_parameter_df.iat[7,2]  # used Integer indexing here as both DF have these attribute in different location

    static_parameter_result_df.iat[4,2] = dynamic_df[dynamic_df["Company"] == Company_name].Weight_Markov
    static_parameter_result_df.iat[5,2] = dynamic_df[dynamic_df["Company"] == Company_name].Weight_What_If
    
    static_parameter_result_df.iat[6,2] = 1/(1-static_parameter_result_df.iat[0,2] * (static_parameter_result_df.iat[1,2]-1))
    static_parameter_result_df.iat[7,2] = static_parameter_result_df.iat[0,2] * static_parameter_result_df.iat[6,2]
    static_parameter_result_df.iat[8,2] = static_parameter_result_df.iat[6,2] - 1
    if ((static_parameter_result_df.iat[2,2]-1) == 0):
        static_parameter_result_df.iat[9,2] = 0
    else :    
        static_parameter_result_df.iat[9,2] = 1/(static_parameter_result_df.iat[2,2]-1)
    
    
    return static_parameter_result_df

def static_parms(steel_model_df):
    static_parameter_result_df2 = pd.DataFrame(columns=["Attribute", "Nature", "Value"])
    attribute_value =['Revenues' , 'EBIT/Revenues' , 'EBIT/Tangible Assets' , 'Total Debt/EBIDTA' , 'Total Debt/Book Capitalization'
                    ,'(Cash Flow from Operations - Dividends) / Total Debt' , 'EBIT / Interest Expenses' ]
    i = 0 
    Nature = "Fixed Value"
    for item in attribute_value:
        static_parameter_result_df2.loc[i] = [item, Nature , np.nan]
        i = i+1
    steel_model_df.set_index('attribute', inplace=True)
    static_parameter_result_df2.loc[static_parameter_result_df2["Attribute"] == 'Revenues' , 'Value'] = steel_model_df.loc['Revenue',"Weight"]

    static_parameter_result_df2.loc[static_parameter_result_df2["Attribute"] == 'EBIT/Revenues' , 'Value'] = steel_model_df.loc['EBIT_Margin',"Weight"]
    static_parameter_result_df2.loc[static_parameter_result_df2["Attribute"] == 'EBIT/Tangible Assets' , 'Value'] = steel_model_df.loc['EBIT_Tangible_Assets',"Weight"]
    static_parameter_result_df2.loc[static_parameter_result_df2["Attribute"] == 'Total Debt/EBIDTA' , 'Value'] = steel_model_df.loc['Debt_EBITDA',"Weight"]
    static_parameter_result_df2.loc[static_parameter_result_df2["Attribute"] == 'Total Debt/Book Capitalization' , 'Value'] = steel_model_df.loc['Debt_Book_Capitalization',"Weight"]
    static_parameter_result_df2.loc[static_parameter_result_df2["Attribute"] == '(Cash Flow from Operations - Dividends) / Total Debt' , 'Value'] = steel_model_df.loc['CFO_Dividends_Debt',"Weight"]
    static_parameter_result_df2.loc[static_parameter_result_df2["Attribute"] == 'EBIT / Interest Expenses' , 'Value'] = steel_model_df.loc['EBIT_Interest_Expense',"Weight"]
    
    return static_parameter_result_df2
# this is the function that we will use the PD Rating for a company
def PD():
    data = {
    'Masterscale': [
    'PD'
    ],
    'AAA':[0.00001] , 'AA+':[0.00001] , 'AA' : [0.00004] , 'AA-' :[0.0001] , 'A+' : [0.00021] 
    , 'A' : [0.0004] , 'A-':[0.0004] , 'BBB+' :[0.00072]
    , 'BBB' :[0.0013] , 'BBB-':[0.0022] , 'BB+':[0.0038]
    ,'BB':[0.0065] , 'BB-':[0.0114] , 'B+':[0.0204]
    ,'B':[0.0382] , 'B-':[0.0754] , 'CCC+':[0.159] 
    , 'CCC':[0.159] , 'CCC-':[0.3495] , 'CC':[0.3495]
    , 'C':[0.5]
    }
    PD = pd.DataFrame(data)
    return PD
# this is the function which we will create rating for the company 
def rating_PD(Fitch_rating , PD):
    value = PD.loc[0, Fitch_rating]
    data = {
    'Initial Ratings': [
    'Rating',
    'PD'],
    'Values':[
    Fitch_rating,
    value]
    }

    df = pd.DataFrame(data)
    return df

def create_algorithm_df(input_parms, static_parameter_result_df,consolidated_df,  reporting_year, reporting_end_year):
    algorithm_result_df = pd.DataFrame(columns = ["Parameters","Increamental_Markov_What_If"])

    Parameters_Value = ['Market Cost Add-on','Market Cost Add-on',
    'Market Price Add-on','Market Price Add-on',
    'Market Price','Market Price','Market Price',
    'Market Quantity','Market Quantity','Market Quantity',
    'Firm Cost Add-on','Firm Cost Add-on',
    'Firm Quantity','Firm Quantity','Firm Quantity',
    'Firm Revenue','Firm Revenue','Firm Revenue',
    'Firm Cost','Firm Cost','Firm Cost',
    'Firm Profit','Firm Profit','Firm Profit',
    ]

    Increamental_Markov_What_If_value = ['Incremental - Markov','Incremental - What-if',
    'Incremental - Markov','Incremental - What-if',
    'Incremental - Markov','Incremental - What-if','Absolute',
    'Incremental - Markov','Incremental - What-if','Absolute',
    'Incremental - Markov','Incremental - What-if',
    'Incremental - Markov','Incremental - What-if','Absolute',
    'Incremental - Markov','Incremental - What-if','Absolute',
    'Incremental - Markov','Incremental - What-if','Absolute',
    'Incremental - Markov','Incremental - What-if','Absolute',
    ]


    for i in range(0,24):
        algorithm_result_df.loc[i] = [Parameters_Value[i],Increamental_Markov_What_If_value[i] ]
        
    x = list(np.arange(int(reporting_year )- 1,  reporting_end_year +1))

    for col in x:
        algorithm_result_df[col] = np.nan
        

    algorithm_result_df.iat[23,2] = consolidated_df.iat[17,1]

    algorithm_result_df.iat[17,2] = 1 

    algorithm_result_df.iat[20,2] = algorithm_result_df.iat[17,2] - algorithm_result_df.iat[23,2]

    algorithm_result_df.iat[14,2] = 1 

    algorithm_result_df.iat[9,2] = 1 

    algorithm_result_df.iat[6,2] = 1
    for current_col_num in range(3, 2050 - int(reporting_year) +4):
        algorithm_result_df.iat[0,current_col_num] = ((input_parms.iat[9,current_col_num] - input_parms.iat[9,current_col_num-1]) * input_parms.iat[0,current_col_num-1] - 
                                        input_parms.iat[4,current_col_num-1] * (input_parms.iat[0,current_col_num] - input_parms.iat[0,current_col_num-1] ) - 
                                        input_parms.iat[5,current_col_num-1]*(input_parms.iat[1,current_col_num] - input_parms.iat[1,current_col_num-1])) / (algorithm_result_df.iat[6,current_col_num - 1] * 1000000)

        algorithm_result_df.iat[1,current_col_num] = ((input_parms.iat[9,current_col_num] - input_parms.iat[9,2]) * input_parms.iat[0,current_col_num-1] - 
                                        input_parms.iat[4,current_col_num-1] * (input_parms.iat[0,current_col_num] - input_parms.iat[0,current_col_num-1] ) - 
                                        input_parms.iat[5,current_col_num-1]*(input_parms.iat[1,current_col_num] - input_parms.iat[1,current_col_num-1])) / (algorithm_result_df.iat[6,2] * 1000000)

        algorithm_result_df.iat[2,current_col_num] = ((input_parms.iat[9,current_col_num] - input_parms.iat[9,current_col_num -1]) * input_parms.iat[1,current_col_num-1]) / (algorithm_result_df.iat[6, current_col_num -1] * 1000000)

        algorithm_result_df.iat[3,current_col_num] = ((input_parms.iat[9,current_col_num] - input_parms.iat[9,2]) * input_parms.iat[1,current_col_num-1]) / (algorithm_result_df.iat[6,2] * 1000000)

        algorithm_result_df.iat[4,current_col_num] = static_parameter_result_df.iat[6,2] * algorithm_result_df.iat[0,current_col_num]  + static_parameter_result_df.iat[8,2] * algorithm_result_df.iat[2,current_col_num] 

        algorithm_result_df.iat[5,current_col_num] = static_parameter_result_df.iat[6,2] * algorithm_result_df.iat[1,current_col_num]  + static_parameter_result_df.iat[8,2] * algorithm_result_df.iat[3,current_col_num] 

        algorithm_result_df.iat[6,current_col_num] = max(static_parameter_result_df.iat[4,2] * algorithm_result_df.iat[6,current_col_num -1] * (1 + algorithm_result_df.iat[4,current_col_num]) + static_parameter_result_df.iat[5,2] * algorithm_result_df.iat[6,2] * (1+ algorithm_result_df.iat[5,current_col_num]), 0.01)

        algorithm_result_df.iat[7,current_col_num] = static_parameter_result_df.iat[7,2] * (algorithm_result_df.iat[0,current_col_num] + algorithm_result_df.iat[2,current_col_num])
            
        algorithm_result_df.iat[8,current_col_num] = static_parameter_result_df.iat[7,2] * (algorithm_result_df.iat[1,current_col_num] + algorithm_result_df.iat[3,current_col_num])

        algorithm_result_df.iat[9,current_col_num] = max(static_parameter_result_df.iat[4,2] * algorithm_result_df.iat[9,current_col_num -1] * (1 + algorithm_result_df.iat[7,current_col_num]) + static_parameter_result_df.iat[5,2] * algorithm_result_df.iat[9,2] * (1 + algorithm_result_df.iat[8,current_col_num]), 0.01)

        algorithm_result_df.iat[10,current_col_num] = ((input_parms.iat[8,current_col_num] - input_parms.iat[8,current_col_num-1]) * input_parms.iat[2,current_col_num -1] 
                                                       - input_parms.iat[6, current_col_num -1] *(input_parms.iat[2,current_col_num] - input_parms.iat[2,current_col_num -1]) 
                                                       - input_parms.iat[7, current_col_num -1] * (input_parms.iat[3,current_col_num] - input_parms.iat[3,current_col_num-1])) / (algorithm_result_df.iat[6,current_col_num -1 ]*1000000)

        algorithm_result_df.iat[11,current_col_num] = ((input_parms.iat[8,current_col_num] - input_parms.iat[8,2]) * input_parms.iat[2,current_col_num -1] 
                                                       - input_parms.iat[6, current_col_num -1] *(input_parms.iat[2,current_col_num] - input_parms.iat[2,current_col_num -1]) 
                                                       - input_parms.iat[7, current_col_num -1] * (input_parms.iat[3,current_col_num] - input_parms.iat[3,current_col_num-1])) / (algorithm_result_df.iat[6,2 ] * 1000000)

        algorithm_result_df.iat[12,current_col_num] = static_parameter_result_df.iat[9,2] * (algorithm_result_df.iat[4,current_col_num] - algorithm_result_df.iat[10,current_col_num])

        algorithm_result_df.iat[13,current_col_num] = static_parameter_result_df.iat[9,2] * (algorithm_result_df.iat[5,current_col_num] - algorithm_result_df.iat[11,current_col_num])

        algorithm_result_df.iat[14,current_col_num] = max(static_parameter_result_df.iat[4,2] * algorithm_result_df.iat[14,current_col_num -1] * (1 + algorithm_result_df.iat[12,current_col_num]) + static_parameter_result_df.iat[5,2] * algorithm_result_df.iat[14,2] * (1 + algorithm_result_df.iat[13,current_col_num]), 0.01)
                                                        
        algorithm_result_df.iat[15,current_col_num] = algorithm_result_df.iat[12,current_col_num] + algorithm_result_df.iat[4,current_col_num]

        algorithm_result_df.iat[16,current_col_num] = algorithm_result_df.iat[5,current_col_num] + algorithm_result_df.iat[13,current_col_num]

        algorithm_result_df.iat[17,current_col_num] = max(static_parameter_result_df.iat[4,2] * algorithm_result_df.iat[17,current_col_num -1] * (1 + algorithm_result_df.iat[15,current_col_num]) + static_parameter_result_df.iat[5,2] * algorithm_result_df.iat[17,2] * (1 + algorithm_result_df.iat[16,current_col_num]), 0.01)

        algorithm_result_df.iat[18,current_col_num] = algorithm_result_df.iat[12,current_col_num] + algorithm_result_df.iat[10,current_col_num]

        algorithm_result_df.iat[19,current_col_num] = algorithm_result_df.iat[13,current_col_num] + algorithm_result_df.iat[11,current_col_num]

        algorithm_result_df.iat[20,current_col_num] = max(static_parameter_result_df.iat[4,2] * (algorithm_result_df.iat[20,current_col_num -1] + algorithm_result_df.iat[17,current_col_num -1] * algorithm_result_df.iat[18,current_col_num ]) + static_parameter_result_df.iat[5,2] * (algorithm_result_df.iat[20,2] + algorithm_result_df.iat[17,2] * algorithm_result_df.iat[19,current_col_num]),0.01)


        algorithm_result_df.iat[21,current_col_num] = algorithm_result_df.iat[15,current_col_num] - algorithm_result_df.iat[18,current_col_num]

        algorithm_result_df.iat[22,current_col_num] = algorithm_result_df.iat[16,current_col_num] - algorithm_result_df.iat[19,current_col_num]

        algorithm_result_df.iat[23,current_col_num] = static_parameter_result_df.iat[4,2] * (algorithm_result_df.iat[23,current_col_num -1] + algorithm_result_df.iat[17,current_col_num -1] * algorithm_result_df.iat[21,current_col_num ]) + static_parameter_result_df.iat[5,2] * (algorithm_result_df.iat[23,2] + algorithm_result_df.iat[17,2] * algorithm_result_df.iat[22,current_col_num])
        
    return algorithm_result_df





def static_PL(consolidated_df , dynamic_df , PL_CF_BS_Mil_df, Company_name):
    company_data = dynamic_df[dynamic_df['Company'] == Company_name]
    if company_data.empty:
        raise ValueError(f"Company '{Company_name}' not found in the dataframe.")
    df = pd.DataFrame(columns=["Static_Paramters", "Nature", "Value"])
    attribute_value =['Tax Rate' , 'Funding Rate' , 'α_D' , 'α_D&A' , 'α_NetIncome'
                    ,'α_RCF' , 'α_FCF', 'α_FFO' , 'α_CFO' , 'α_Cash' , 'α_MarketSec'
                    , 'α_NetDebt' , 'Weight - Assets (ω)' , 'Weight - Debt']

    df.loc[0] = ['Tax Rate', 'Fixed Value', np.nan]

    i = 1
    Nature = "Implied"
    for item in attribute_value:
        df.loc[i] = [item, Nature , np.nan]
        i = i+1

    df.drop(1, inplace = True)
    df.reset_index(drop=True, inplace = True)
    
    consolidated_df.set_index('attribute', inplace = True)
    df.loc[df["Static_Paramters"] == 'Tax Rate' , 'Value'] = consolidated_df.loc['Tax_Rate' , 'Value']
    df.iat[1,2] =(PL_CF_BS_Mil_df.iat[6,2])/(PL_CF_BS_Mil_df.iat[17,2])
    df.iat[2,2] =(PL_CF_BS_Mil_df.iat[2,2])/(PL_CF_BS_Mil_df.iat[0,2])
    df.iat[3,2] =(PL_CF_BS_Mil_df.iat[4,2])/(PL_CF_BS_Mil_df.iat[0,2])
    df.iat[4,2] =(PL_CF_BS_Mil_df.iat[7,2])/((1-df.iat[0,2])*(PL_CF_BS_Mil_df.iat[5,2] - PL_CF_BS_Mil_df.iat[6,2]))
    df.iat[5,2] =(PL_CF_BS_Mil_df.iat[9,2])/((PL_CF_BS_Mil_df.iat[1,2] - PL_CF_BS_Mil_df.iat[13,2]))
    df.iat[6,2] =(PL_CF_BS_Mil_df.iat[10,2])/((PL_CF_BS_Mil_df.iat[1,2] - PL_CF_BS_Mil_df.iat[13,2] -PL_CF_BS_Mil_df.iat[14,2]))
    df.iat[7,2] =(PL_CF_BS_Mil_df.iat[11,2])/((PL_CF_BS_Mil_df.iat[1,2] - PL_CF_BS_Mil_df.iat[6,2]))
    df.iat[8,2] =(PL_CF_BS_Mil_df.iat[12,2])/((PL_CF_BS_Mil_df.iat[1,2] - PL_CF_BS_Mil_df.iat[6,2]))
    df.iat[9,2] = (PL_CF_BS_Mil_df.iat[18,2])/(PL_CF_BS_Mil_df.iat[16,2])
    df.iat[10,2] = (PL_CF_BS_Mil_df.iat[19,2])/(PL_CF_BS_Mil_df.iat[16,2])
    df.iat[11,2] = (PL_CF_BS_Mil_df.iat[20,2])/(PL_CF_BS_Mil_df.iat[17,2])
    df.loc[df["Static_Paramters"] == 'Weight - Assets (ω)' , 'Value'] = company_data.iloc[0]['Weight_Assets']
    df.loc[df["Static_Paramters"] == 'Weight - Debt' , 'Value'] = company_data.iloc[0]['Weight_Debt']
    
    consolidated_df.reset_index(inplace=True)
    return df



def create_pl_cf_static_param_df(input_parms, distance_default_parameter_df,consolidated_df, dynamic_df,algorithm_result_df, Company_name, reporting_year, reporting_end_year):
    PL_CF_BS_Mil_df = pd.DataFrame(columns = ["Parameters","Base_Implied"])


    T5_Parameters_Value = ['P&L – Revenues','P&L – EBITDA','P&L – Depreciations','P&L – EBITA','P&L – Depreciations & Amortizations','P&L – EBIT','P&L – Interest Expenses',
    'P&L – Net Income','P&L – Operating Income','CF – Retained Cash Flow','CF – Free Cash Flow','CF – Funds from Operations','CF – Cash Flow from Operations',
    'CF – Dividends','CF – Capital Expenditure','BS – Equity','BS – Total Assets','BS – Total Debt','BS – Cash','BS – Marketable Securities','BS – Net Debt',
    'BS – Preferred Stock','BS – Book Capitalization','BS – Capitalized Interest','BS – Secured Debt','BS – Tangible Assets']

    T5_Base_Implied_value = ['Base','Base','Implied','Base','Implied','Base','Base','Implied','Implied','Implied','Implied','Implied','Implied','Base',
    'Base','Base','Base','Implied','Base','Base','Implied','Implied','Base','Implied','Implied','Implied',]


    for i in range(0,26):
        PL_CF_BS_Mil_df.loc[i] = [T5_Parameters_Value[i],T5_Base_Implied_value[i] ]

    x = list(np.arange(int(reporting_year )- 1,  reporting_end_year +1))
        
    for col in x:
        PL_CF_BS_Mil_df[col] = np.nan
        
    'Revenue_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[0,2] = distance_default_parameter_df.iat[0,1]

    'EBITDA_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[1,2] = distance_default_parameter_df.iat[1,1]

    'EBITA_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[3,2] = distance_default_parameter_df.iat[2,1]

    'EBIT_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[5,2] = distance_default_parameter_df.iat[3,1]

    'Interest_exp_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[6,2] = distance_default_parameter_df.iat[4,1]

    'CF_dividends_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[13,2] = distance_default_parameter_df.iat[5,1]

    'Cap_exp_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[14,2] = distance_default_parameter_df.iat[6,1]

    'Equity_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[15,2] = distance_default_parameter_df.iat[7,1]

    'T_assets_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[16,2] = distance_default_parameter_df.iat[8,1]

    'Cash_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[18,2] = distance_default_parameter_df.iat[9,1]

    'Mrkt_sec_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[19,2] = distance_default_parameter_df.iat[11,1]

    'book_capital_Base_col_index_1'
    PL_CF_BS_Mil_df.iat[22,2] = distance_default_parameter_df.iat[10,1]

    'Depreciation_implied_col_index_2'
    PL_CF_BS_Mil_df.iat[2,2] = PL_CF_BS_Mil_df.iat[1,2]-PL_CF_BS_Mil_df.iat[3,2]

    'Dep_Amort_implied_col_index_2'
    PL_CF_BS_Mil_df.iat[4,2] = PL_CF_BS_Mil_df.iat[1,2]-PL_CF_BS_Mil_df.iat[5,2]

    'Net_income_implied_col_index_2' #(Formula is incomplete, need to create Static table above it in results sheet)
    PL_CF_BS_Mil_df.iat[7,2] = (1-consolidated_df.iat[2,1])*(PL_CF_BS_Mil_df.iat[5,2]-PL_CF_BS_Mil_df.iat[6,2])

    'op_income_implied_col_index_2' 
    PL_CF_BS_Mil_df.iat[8,2] = PL_CF_BS_Mil_df.iat[5,2]

    'free_cash_F_implied_col_index_2' 
    PL_CF_BS_Mil_df.iat[10,2] = PL_CF_BS_Mil_df.iat[1,2]-PL_CF_BS_Mil_df.iat[13,2]-PL_CF_BS_Mil_df.iat[14,2]

    'funds_f_ops_implied_col_index_2' 
    PL_CF_BS_Mil_df.iat[11,2] = PL_CF_BS_Mil_df.iat[1,2]-PL_CF_BS_Mil_df.iat[6,2]

    'cash_flow_f_ops_implied_col_index_2' 
    PL_CF_BS_Mil_df.iat[12,2] = PL_CF_BS_Mil_df.iat[1,2]-PL_CF_BS_Mil_df.iat[6,2]

    'Total_debt_implied_col_index_2' 
    PL_CF_BS_Mil_df.iat[17,2] = PL_CF_BS_Mil_df.iat[16,2]-PL_CF_BS_Mil_df.iat[15,2]

    'Net_debt_implied_col_index_2' 
    PL_CF_BS_Mil_df.iat[20,2] = PL_CF_BS_Mil_df.iat[17,2]-PL_CF_BS_Mil_df.iat[18,2]-PL_CF_BS_Mil_df.iat[19,2]

    'pref_stock_implied_col_index_2' 
    PL_CF_BS_Mil_df.iat[21,2] = (0.2*PL_CF_BS_Mil_df.iat[15,2])

    'cap_intrst_implied_col_index_2' 
    PL_CF_BS_Mil_df.iat[23,2] = PL_CF_BS_Mil_df.iat[6,2]

    'sec_debt_implied_col_index_2' 
    PL_CF_BS_Mil_df.iat[24,2] = (0.6*PL_CF_BS_Mil_df.iat[17,2])

    'Tang_Assets_implied_col_index_2' 
    PL_CF_BS_Mil_df.iat[25,2] = (0.8*PL_CF_BS_Mil_df.iat[16,2])

    'Retained_cash_F_implied_col_index_2'
    PL_CF_BS_Mil_df.iat[9,2] = PL_CF_BS_Mil_df.iat[11,2]-PL_CF_BS_Mil_df.iat[13,2]

    static_paramater_P_L = static_PL(consolidated_df , dynamic_df ,PL_CF_BS_Mil_df ,Company_name)

    #fomrula to calculate CF – Dividends col_index_3 value in table "P&L / CF / BS ($ millions)"
    def calculate_formula(Row_107, Row_119, Rw_107):
        if Row_107 > 0:
            return Row_107 * Row_119 / Rw_107
        else:
            return 0
        
    
    for current_col_num in range(3, 2050 - int(reporting_year) +4):
        PL_CF_BS_Mil_df.iat[0,current_col_num] = PL_CF_BS_Mil_df.iat[0,2]*algorithm_result_df.iat[17,current_col_num]
        PL_CF_BS_Mil_df.iat[1,current_col_num] = PL_CF_BS_Mil_df.iat[1,2]*algorithm_result_df.iat[23,current_col_num]/algorithm_result_df.iat[23,2]
        PL_CF_BS_Mil_df.iat[2,current_col_num] = PL_CF_BS_Mil_df.iat[2,current_col_num-1]
        PL_CF_BS_Mil_df.iat[3,current_col_num] = PL_CF_BS_Mil_df.iat[1,current_col_num]-PL_CF_BS_Mil_df.iat[2,current_col_num]
        PL_CF_BS_Mil_df.iat[4,current_col_num] = PL_CF_BS_Mil_df.iat[4,current_col_num-1]
        PL_CF_BS_Mil_df.iat[5,current_col_num] = PL_CF_BS_Mil_df.iat[1,current_col_num]-PL_CF_BS_Mil_df.iat[4,current_col_num]
        PL_CF_BS_Mil_df.iat[6,current_col_num] = static_paramater_P_L.iat[1,2]*PL_CF_BS_Mil_df.iat[17,current_col_num-1]
        PL_CF_BS_Mil_df.iat[7,current_col_num] = (1- static_paramater_P_L.iat[0,2])* (PL_CF_BS_Mil_df.iat[5,current_col_num]- PL_CF_BS_Mil_df.iat[6,current_col_num])
        PL_CF_BS_Mil_df.iat[8,current_col_num] = PL_CF_BS_Mil_df.iat[5,current_col_num]

        PL_CF_BS_Mil_df.iat[12,current_col_num] = PL_CF_BS_Mil_df.iat[1,current_col_num]-PL_CF_BS_Mil_df.iat[6,current_col_num]
        PL_CF_BS_Mil_df.iat[13,current_col_num] = calculate_formula(PL_CF_BS_Mil_df.iat[1,current_col_num], PL_CF_BS_Mil_df.iat[13,2], PL_CF_BS_Mil_df.iat[1,2])
        PL_CF_BS_Mil_df.iat[14,current_col_num] = PL_CF_BS_Mil_df.iat[0,current_col_num] *  PL_CF_BS_Mil_df.iat[14,2] /  PL_CF_BS_Mil_df.iat[0,2]
        PL_CF_BS_Mil_df.iat[15,current_col_num] = PL_CF_BS_Mil_df.iat[15,2] + PL_CF_BS_Mil_df.iat[7,current_col_num]-PL_CF_BS_Mil_df.iat[7,2] - PL_CF_BS_Mil_df.iat[13,current_col_num] + PL_CF_BS_Mil_df.iat[13,2]
        PL_CF_BS_Mil_df.iat[16,current_col_num] = PL_CF_BS_Mil_df.iat[16,2] + static_paramater_P_L.iat[12,2] *  (PL_CF_BS_Mil_df.iat[15,current_col_num]-PL_CF_BS_Mil_df.iat[15,2])
        PL_CF_BS_Mil_df.iat[17,current_col_num] = PL_CF_BS_Mil_df.iat[17,2] - static_paramater_P_L.iat[13,2] *  (PL_CF_BS_Mil_df.iat[15,current_col_num]-PL_CF_BS_Mil_df.iat[15,2])
        PL_CF_BS_Mil_df.iat[18,current_col_num] = static_paramater_P_L.iat[9,2] * PL_CF_BS_Mil_df.iat[16,current_col_num]
        PL_CF_BS_Mil_df.iat[19,current_col_num] = static_paramater_P_L.iat[10,2] * PL_CF_BS_Mil_df.iat[16,current_col_num]
        PL_CF_BS_Mil_df.iat[20,current_col_num] = PL_CF_BS_Mil_df.iat[17,current_col_num] - PL_CF_BS_Mil_df.iat[18,current_col_num] - PL_CF_BS_Mil_df.iat[19,current_col_num] 
        PL_CF_BS_Mil_df.iat[21,current_col_num] = PL_CF_BS_Mil_df.iat[16,current_col_num] * PL_CF_BS_Mil_df.iat[21,2] / PL_CF_BS_Mil_df.iat[16,2] 
        PL_CF_BS_Mil_df.iat[22,current_col_num] = PL_CF_BS_Mil_df.iat[16,current_col_num] * PL_CF_BS_Mil_df.iat[22,2] / PL_CF_BS_Mil_df.iat[16,2] 
        PL_CF_BS_Mil_df.iat[23,current_col_num] = PL_CF_BS_Mil_df.iat[16,current_col_num] * PL_CF_BS_Mil_df.iat[23,2] / PL_CF_BS_Mil_df.iat[16,2] 
        PL_CF_BS_Mil_df.iat[24,current_col_num] = PL_CF_BS_Mil_df.iat[17,current_col_num] * PL_CF_BS_Mil_df.iat[24,2] / PL_CF_BS_Mil_df.iat[17,2] 
        PL_CF_BS_Mil_df.iat[25,current_col_num] = PL_CF_BS_Mil_df.iat[16,current_col_num] * PL_CF_BS_Mil_df.iat[25,2] / PL_CF_BS_Mil_df.iat[16,2] 


        PL_CF_BS_Mil_df.iat[10,current_col_num] = PL_CF_BS_Mil_df.iat[1,current_col_num]-PL_CF_BS_Mil_df.iat[13,current_col_num]-PL_CF_BS_Mil_df.iat[14,current_col_num]
        PL_CF_BS_Mil_df.iat[11,current_col_num] = PL_CF_BS_Mil_df.iat[1,current_col_num]-PL_CF_BS_Mil_df.iat[6,current_col_num]

        PL_CF_BS_Mil_df.iat[9,current_col_num] = PL_CF_BS_Mil_df.iat[11,current_col_num]-PL_CF_BS_Mil_df.iat[13,current_col_num]
        
    return PL_CF_BS_Mil_df , static_paramater_P_L

# Create Ratios DF from result sheet
def create_ratios_df(PL_CF_BS_Mil_df, reporting_year):
    col_list= ["Attribute"] + list(PL_CF_BS_Mil_df.columns[2:])


    ratios_df = pd.DataFrame(columns = col_list)

    attribute_value = ['EBITA / Revenues', 'Total Debt / EBITDA', 'Retained Cash Flow / Net Debt', 'Retained Cash Flow / Total Debt',
                       'Free Cash Flow / Total Debt', 'EBITA / Interest Expenses', '(Cash + Marketable Securities) / Total Debt', 
                       'EBIT / Revenues', '(Funds from Operations + Interest Expenses) / Interest Expenses', 'Equity / Total Assets',
                       'EBIT / Interest Expenses', 'EBITDA / Revenues', 'Net Debt / EBITDA', 'Funds from Operations / Total Debt',
                       'Cash Flow from Operations / Total Debt', 'EBITDA / Interest Expenses', 'Total Assets', 'Revenues', '(Cash Flow from Operations - Dividends) / Total Debt',
                       '(Cash Flow from Operations + Interest Expenses) / Interest Expenses', '(Funds from Operations - Capital Expenditures) / Dividends',
                       '(Retained Cash Flow - Capital Expenditures) / Total Debt', '(Total Debt + Preferred Stocks) / Total Assets', 
                       'Total Debt / Book Capitalization', 'EBIT / Book Capitalization', 'EBIT / Tangible Assets', 'EBIT / Total Assets',
                       'Revenues / Total Debt', 'EBITA / Total Assets', 'Secured Debt / Total Assets', 'EBITDA / (Interest Expenses + Capitalized Interest + Dividends)',
                       'Funds from Operations / Net Debt', 'Operating Income / Total Assets', 'Operating Income / Book Capitalization', 'Operating Income / Revenues',
                       'Operating Income', 'EBITA', 'EBITDA', 'EBIT', 'Total Assets (Mn EUR)', 'Total Debt / Total Assets', 'EBITDA  /  Total Assets']

    #Inserting np.nan in all cells of dataframe with lenght of attribute_value(required number of rows)
    for x in range (len(attribute_value)):
        ratios_df.loc[len(ratios_df)] = np.nan

    #Updating attribute_value in Column Attribute of dataframe to get required rows
    for index, row in ratios_df.iterrows():
        ratios_df.at[index, "Attribute"] = attribute_value[index]
    #Updating values in Year columns
    for current_col_index in range(1, 2050 - int(reporting_year) +3):
        ratios_df.iat[0,current_col_index] = PL_CF_BS_Mil_df.iat[3,current_col_index +1] / PL_CF_BS_Mil_df.iat[0,current_col_index +1]
        ratios_df.iat[1,current_col_index] = PL_CF_BS_Mil_df.iat[17,current_col_index +1] / PL_CF_BS_Mil_df.iat[1,current_col_index +1]
        ratios_df.iat[2,current_col_index] = PL_CF_BS_Mil_df.iat[9,current_col_index +1] / PL_CF_BS_Mil_df.iat[20,current_col_index +1]
        ratios_df.iat[3,current_col_index] = PL_CF_BS_Mil_df.iat[9,current_col_index +1] / PL_CF_BS_Mil_df.iat[17,current_col_index +1]
        ratios_df.iat[4,current_col_index] = PL_CF_BS_Mil_df.iat[10,current_col_index +1] / PL_CF_BS_Mil_df.iat[17,current_col_index +1]
        ratios_df.iat[5,current_col_index] = PL_CF_BS_Mil_df.iat[3,current_col_index +1] / PL_CF_BS_Mil_df.iat[6,current_col_index +1]
        ratios_df.iat[6,current_col_index] = (PL_CF_BS_Mil_df.iat[18,current_col_index +1] + PL_CF_BS_Mil_df.iat[19,current_col_index +1]) / PL_CF_BS_Mil_df.iat[17,current_col_index +1]
        ratios_df.iat[7,current_col_index] = PL_CF_BS_Mil_df.iat[5,current_col_index +1] / PL_CF_BS_Mil_df.iat[0,current_col_index +1]
        ratios_df.iat[8,current_col_index] = (PL_CF_BS_Mil_df.iat[11,current_col_index +1] + PL_CF_BS_Mil_df.iat[6,current_col_index +1]) / PL_CF_BS_Mil_df.iat[6,current_col_index +1]
        ratios_df.iat[9,current_col_index] = PL_CF_BS_Mil_df.iat[15,current_col_index +1] / PL_CF_BS_Mil_df.iat[16,current_col_index +1]
        ratios_df.iat[10,current_col_index] = PL_CF_BS_Mil_df.iat[5,current_col_index +1] / PL_CF_BS_Mil_df.iat[6,current_col_index +1]
        ratios_df.iat[11,current_col_index] = PL_CF_BS_Mil_df.iat[1,current_col_index +1] / PL_CF_BS_Mil_df.iat[0,current_col_index +1]
        ratios_df.iat[12,current_col_index] = PL_CF_BS_Mil_df.iat[20,current_col_index +1] / PL_CF_BS_Mil_df.iat[1,current_col_index +1]
        ratios_df.iat[13,current_col_index] = PL_CF_BS_Mil_df.iat[11,current_col_index +1] / PL_CF_BS_Mil_df.iat[17,current_col_index +1]
        ratios_df.iat[14,current_col_index] = PL_CF_BS_Mil_df.iat[12,current_col_index +1] / PL_CF_BS_Mil_df.iat[17,current_col_index +1]
        ratios_df.iat[15,current_col_index] = PL_CF_BS_Mil_df.iat[1,current_col_index +1] / PL_CF_BS_Mil_df.iat[6,current_col_index +1]
        ratios_df.iat[16,current_col_index] = PL_CF_BS_Mil_df.iat[16,current_col_index +1] / 1000
        ratios_df.iat[17,current_col_index] = PL_CF_BS_Mil_df.iat[0,current_col_index +1] / 1000
        ratios_df.iat[18,current_col_index] = (PL_CF_BS_Mil_df.iat[12,current_col_index +1] - PL_CF_BS_Mil_df.iat[13,current_col_index +1]) / PL_CF_BS_Mil_df.iat[17,current_col_index +1]
        ratios_df.iat[19,current_col_index] = (PL_CF_BS_Mil_df.iat[12,current_col_index +1] + PL_CF_BS_Mil_df.iat[6,current_col_index +1]) / PL_CF_BS_Mil_df.iat[6,current_col_index +1]
        ratios_df.iat[20,current_col_index] = (PL_CF_BS_Mil_df.iat[11,current_col_index +1] - PL_CF_BS_Mil_df.iat[14,current_col_index +1]) / PL_CF_BS_Mil_df.iat[17,current_col_index +1]
        ratios_df.iat[21,current_col_index] = (PL_CF_BS_Mil_df.iat[9,current_col_index +1] - PL_CF_BS_Mil_df.iat[14,current_col_index +1]) / PL_CF_BS_Mil_df.iat[17,current_col_index +1]
        ratios_df.iat[22,current_col_index] = (PL_CF_BS_Mil_df.iat[17,current_col_index +1] + PL_CF_BS_Mil_df.iat[21,current_col_index +1]) / PL_CF_BS_Mil_df.iat[16,current_col_index +1]
        ratios_df.iat[23,current_col_index] = PL_CF_BS_Mil_df.iat[17,current_col_index +1] / PL_CF_BS_Mil_df.iat[22,current_col_index +1]
        ratios_df.iat[24,current_col_index] = PL_CF_BS_Mil_df.iat[5,current_col_index +1] / PL_CF_BS_Mil_df.iat[22,current_col_index +1]
        ratios_df.iat[25,current_col_index] = PL_CF_BS_Mil_df.iat[5,current_col_index +1] / PL_CF_BS_Mil_df.iat[25,current_col_index +1]
        ratios_df.iat[26,current_col_index] = PL_CF_BS_Mil_df.iat[5,current_col_index +1] / PL_CF_BS_Mil_df.iat[16,current_col_index +1]
        ratios_df.iat[27,current_col_index] = PL_CF_BS_Mil_df.iat[0,current_col_index +1] / PL_CF_BS_Mil_df.iat[17,current_col_index +1]
        ratios_df.iat[28,current_col_index] = PL_CF_BS_Mil_df.iat[1,current_col_index +1] / PL_CF_BS_Mil_df.iat[16,current_col_index +1]
        ratios_df.iat[29,current_col_index] = PL_CF_BS_Mil_df.iat[24,current_col_index +1] / PL_CF_BS_Mil_df.iat[16,current_col_index +1]
        ratios_df.iat[30,current_col_index] = PL_CF_BS_Mil_df.iat[1,current_col_index +1] / (PL_CF_BS_Mil_df.iat[6,current_col_index +1] + PL_CF_BS_Mil_df.iat[23,current_col_index +1] + PL_CF_BS_Mil_df.iat[13,current_col_index +1])
        ratios_df.iat[31,current_col_index] = PL_CF_BS_Mil_df.iat[11,current_col_index +1] / PL_CF_BS_Mil_df.iat[20,current_col_index +1]
        ratios_df.iat[32,current_col_index] = PL_CF_BS_Mil_df.iat[8,current_col_index +1] / PL_CF_BS_Mil_df.iat[16,current_col_index +1]
        ratios_df.iat[33,current_col_index] = PL_CF_BS_Mil_df.iat[8,current_col_index +1] / PL_CF_BS_Mil_df.iat[22,current_col_index +1]
        ratios_df.iat[34,current_col_index] = PL_CF_BS_Mil_df.iat[8,current_col_index +1] / PL_CF_BS_Mil_df.iat[0,current_col_index +1]
        ratios_df.iat[35,current_col_index] = PL_CF_BS_Mil_df.iat[8,current_col_index +1] / 1000
        ratios_df.iat[36,current_col_index] = PL_CF_BS_Mil_df.iat[3,current_col_index +1] / 1000
        ratios_df.iat[37,current_col_index] = PL_CF_BS_Mil_df.iat[1,current_col_index +1] / 1000
        ratios_df.iat[38,current_col_index] = PL_CF_BS_Mil_df.iat[5,current_col_index +1] / 1000
        ratios_df.iat[39,current_col_index] = 0.85 * PL_CF_BS_Mil_df.iat[16,current_col_index +1]
        ratios_df.iat[40,current_col_index] = PL_CF_BS_Mil_df.iat[17,current_col_index +1] / PL_CF_BS_Mil_df.iat[16,current_col_index +1]
        ratios_df.iat[41,current_col_index] = PL_CF_BS_Mil_df.iat[1,current_col_index +1] / PL_CF_BS_Mil_df.iat[16,current_col_index +1]
    return ratios_df


def create_normalized_ratio_df(ratios_df):
    normalized_ratios_df = pd.DataFrame()

    for index in range (len(ratios_df)):
        for col in ratios_df.columns[:]:
            if col == "Attribute":
                normalized_ratios_df.loc[index, col] = ratios_df.loc[index, col]
            else:
                normalized_ratios_df.loc[index,col] = ratios_df.loc[index, col] / ratios_df.iat[index, 1]
    return normalized_ratios_df


def create_selected_ratios_df(normalized_ratios_df, sector_model):
    column_mapping = { 'Revenues' : 'Revenues',
    'Debt_EBITDA' : 'Total Debt / EBITDA',
    'Debt_Book_Capitalization' : 'Total Debt / Book Capitalization',
    'EBIT_Interest_Expenses' : 'EBIT / Interest Expenses',
    'RCF_Net_Debt' : 'Retained Cash Flow / Net Debt',
    'EBIT_Revenues' : 'EBIT / Revenues',
    'EBIT_Assets' : 'EBIT / Total Assets',
    'EBITDA_Revenues' : 'EBITDA / Revenues',
    'EBITDA_Interest_Expenses' : 'EBITA / Interest Expenses',
    'CFO_Dividends_Debt' : '(Cash Flow from Operations - Dividends) / Total Debt',
    'EBITDA' : 'EBITDA',
    'FCF_Debt' : 'Free Cash Flow / Total Debt',
    'EBIT_Book_Capitalization' : 'EBIT / Book Capitalization',
    'EBIT_Tangible_Assets' : 'EBIT / Tangible Assets'
        }

    sector_model_updated = sector_model.copy()      

    sector_model_updated["index"] = sector_model_updated["index"] .map(column_mapping)

    required_attribute_for_selected_ratio = list(sector_model_updated["index"])

    selected_ratio = normalized_ratios_df[normalized_ratios_df["Attribute"].isin(required_attribute_for_selected_ratio)]
    selected_ratio.reset_index(inplace = True, drop=True)
    return selected_ratio


def create_selected_static_param_df(sector_model):
    column_mapping = { 'Revenues' : 'Revenues',
    'Debt_EBITDA' : 'Total Debt / EBITDA',
    'Debt_Book_Capitalization' : 'Total Debt / Book Capitalization',
    'EBIT_Interest_Expenses' : 'EBIT / Interest Expenses',
    'RCF_Net_Debt' : 'Retained Cash Flow / Net Debt',
    'EBIT_Revenues' : 'EBIT / Revenues',
    'EBIT_Assets' : 'EBIT / Total Assets',
    'EBITDA_Revenues' : 'EBITDA / Revenues',
    'EBITDA_Interest_Expenses' : 'EBITA / Interest Expenses',
    'CFO_Dividends_Debt' : '(Cash Flow from Operations - Dividends) / Total Debt',
    'EBITDA' : 'EBITDA',
    'FCF_Debt' : 'Free Cash Flow / Total Debt',
    'EBIT_Book_Capitalization' : 'EBIT / Book Capitalization',
    'EBIT_Tangible_Assets' : 'EBIT / Tangible Assets'
        }

    sector_model_updated = sector_model.copy()      

    sector_model_updated["index"] = sector_model_updated["index"] .map(column_mapping)
    
    sector_model_updated = sector_model_updated[["index", "Scaled Weights"]]

    
    return sector_model_updated


def func1(PL_CF_BS_Mil_df, scenario, filter_cat,reporting_year, reporting_end_year):
    x = list(np.arange(int(reporting_year )- 1,  reporting_end_year +1))
    
    col_list = ['Parameters', 'Base_Implied'] + x + ["Scenario"]
    
    temp_df = pd.DataFrame(columns =col_list)
    if scenario not in temp_df.Scenario:
       df = PL_CF_BS_Mil_df[PL_CF_BS_Mil_df["Parameters"] == filter_cat]
       df["Scenario"] = scenario
       temp_df = pd.concat([df,temp_df], ignore_index = True)
        
    return temp_df

def func2(PL_CF_BS_Mil_df, revenue_df, scenario,filter_cat):
    if scenario not in revenue_df.Scenario:
       df = PL_CF_BS_Mil_df[PL_CF_BS_Mil_df["Parameters"] == filter_cat]
       df["Scenario"] = scenario
       revenue_df = pd.concat([df,revenue_df], ignore_index = True)
       
    return revenue_df

import math as m
def delta_scroes(model_df , selected_ratio , Company_name , reporting_year , initial_rating, static_param_sector_model_df):
    df_temp = model_df[model_df["Company"] == Company_name]
    model = df_temp["Model"].values[0]
    attribute_value = list(selected_ratio["Attribute"])
    col_list = selected_ratio.columns.tolist()
    df = pd.DataFrame(columns = col_list)
    pD = pd.DataFrame(columns = col_list)
    attribute_pd = ["PD"]
    for x in range (len(attribute_pd)):
        pD.loc[len(pD)] = 0
    for index, row in pD.iterrows():
        pD.at[index, "Attribute"] = attribute_pd[index]
    for x in range (len(attribute_value)):
        df.loc[len(df)] = np.nan
    for index, row in df.iterrows():
        df.at[index, "Attribute"] = attribute_value[index]
    rating = initial_rating.iloc[1]["Values"]
    if model == "Cement":
        for current_col_index in range(1, 2050 - int(reporting_year) +3):
            for i in range(len(selected_ratio)):
                df.iat[i,current_col_index] = selected_ratio.iat[i,current_col_index] - selected_ratio.iat[i,1]
           
                pD.iat[0,current_col_index] += df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1]
            pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
        return df,pD
    if model == "Textile":
        for current_col_index in range(1 , 2050 - int(reporting_year) +3 ):
            for i in range(len(selected_ratio)):
                df.iat[i,current_col_index] = selected_ratio.iat[i,current_col_index] - selected_ratio.iat[i,1]
           
                pD.iat[0,current_col_index] += (df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1])
            pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
        return df,pD
    if model == "Steel":
        for current_col_index in range(1 , 2050 - int(reporting_year) +3):
            for i in range(len(selected_ratio)):
                df.iat[i,current_col_index] = selected_ratio.iat[i,current_col_index] - selected_ratio.iat[i,1]
                pD.iat[0,current_col_index] += df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1]
            pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
           
        return df,pD    
    if model == "Oil and Gas":
        for current_col_index in range(1, 2050 - int(reporting_year) + 3):
            for i in range(len(selected_ratio)):
                df.iat[i,current_col_index] = selected_ratio.iat[i,current_col_index] - selected_ratio.iat[i,1]
                pD.iat[0,current_col_index] += df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1]
            pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
           
        return df,pD    
    if model == "Metals & Mining":
        for current_col_index in range(1 , 2050 - int(reporting_year)+3):
            for i in range(len(selected_ratio)):
                df.iat[i,current_col_index] = selected_ratio.iat[i,current_col_index] - selected_ratio.iat[i,1]
                pD.iat[0,current_col_index] += df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1]
            pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
           
        return df,pD
 
    if model == "Infrastructure":
        for current_col_index in range(1 , 2050 - int(reporting_year) +3):
            for i in range(len(selected_ratio)):
                df.iat[i,current_col_index] = selected_ratio.iat[i,current_col_index] - selected_ratio.iat[i,1]
                pD.iat[0,current_col_index] += (df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1])
            pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
        return df,pD
    if model == "Chemical":
        for current_col_index in range(1 , 2050 - int(reporting_year) + 3):
            for i in range(len(selected_ratio)):
                df.iat[i,current_col_index] = selected_ratio.iat[i,current_col_index] - selected_ratio.iat[i,1]
                pD.iat[0,current_col_index] += df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1]      
            pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
        return df,pD
    
def delta_func1(PD_calculated , reporting_year , reporting_end_year , scenario):
    x = list(np.arange(int(reporting_year )- 1,  reporting_end_year +1))

    col_list = ['Attribute'] + ["Scenario"] + x

    temp_df = pd.DataFrame(columns =col_list)
    if scenario not in temp_df.Scenario:
        df = PD_calculated[PD_calculated["Attribute"] == "PD"]
        df["Scenario"] = scenario
        temp_df = pd.concat([df,temp_df], ignore_index = True)
    return temp_df


def delta_func2(PD_calculated, revenue_df, scenario):
    if scenario not in revenue_df.Scenario:
      df = PD_calculated[PD_calculated["Attribute"] == "PD"]
      df["Scenario"] = scenario
      revenue_df = pd.concat([df,revenue_df], ignore_index = True)
       
    return revenue_df



    
                    
            

# def delta_scroes(model_df , selected_ratio , Company_name , reporting_year , initial_rating , static_param_sector_model_df):
#     df_temp = model_df[model_df["Company"] == Company_name]
#     model = df_temp["Model"].values[0] 
#     attribute_value = list(selected_ratio["Attribute"]) 
#     col_list = selected_ratio.columns.tolist()
#     df = pd.DataFrame(columns = col_list)
#     pD = pd.DataFrame(columns = col_list)
#     attribute_pd = ["PD"]
#     for x in range (len(attribute_pd)):
#         pD.loc[len(pD)] = 0
#     for index, row in pD.iterrows():
#         pD.at[index, "Attribute"] = attribute_pd[index]
#     for x in range (len(attribute_value)):
#         df.loc[len(df)] = np.nan
#     for index, row in df.iterrows():
#         df.at[index, "Attribute"] = attribute_value[index]
#     rating = initial_rating.iloc[1]["Values"]
#     if model == "Cement":
#         for current_col_index in range(1, 2050 - int(reporting_year) +3):
#             df.iat[0,current_col_index] = selected_ratio.iat[0,current_col_index] - selected_ratio.iat[0,1]
#             df.iat[1,current_col_index] = selected_ratio.iat[1,current_col_index] - selected_ratio.iat[1,1]
#             df.iat[2,current_col_index] = selected_ratio.iat[2,current_col_index] - selected_ratio.iat[2,1]
#             df.iat[3,current_col_index] = selected_ratio.iat[3,current_col_index] - selected_ratio.iat[3,1]
#             df.iat[4,current_col_index] = selected_ratio.iat[4,current_col_index] - selected_ratio.iat[4,1]
#             df.iat[5,current_col_index] = selected_ratio.iat[5,current_col_index] - selected_ratio.iat[5,1]
#             df.iat[6,current_col_index] = selected_ratio.iat[6,current_col_index] - selected_ratio.iat[6,1]
#             for i in range(len(selected_ratio)):
#                 pD.iat[0,current_col_index] += df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1]
#             pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
#         return df,pD
#     if model == "Textile":
#         for current_col_index in range(1 , 2050 - int(reporting_year) +3 ):
#             df.iat[0,current_col_index] = selected_ratio.iat[0,current_col_index] - selected_ratio.iat[0,1]
#             df.iat[1,current_col_index] = selected_ratio.iat[1,current_col_index] - selected_ratio.iat[1,1]
#             df.iat[2,current_col_index] = selected_ratio.iat[2,current_col_index] - selected_ratio.iat[2,1]
#             df.iat[3,current_col_index] = selected_ratio.iat[3,current_col_index] - selected_ratio.iat[3,1]
#             for i in range(len(selected_ratio)):
#                 pD.iat[0,current_col_index] += (df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1])
#             pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
#         return df,pD
#     if model == "Steel":
#         for current_col_index in range(1 , 2050 - int(reporting_year) +3):
#             df.iat[0,current_col_index] = selected_ratio.iat[0,current_col_index] - selected_ratio.iat[0,1]
#             df.iat[1,current_col_index] = selected_ratio.iat[1,current_col_index] - selected_ratio.iat[1,1]
#             df.iat[2,current_col_index] = selected_ratio.iat[2,current_col_index] - selected_ratio.iat[2,1]
#             df.iat[3,current_col_index] = selected_ratio.iat[3,current_col_index] - selected_ratio.iat[3,1]
#             df.iat[4,current_col_index] = selected_ratio.iat[4,current_col_index] - selected_ratio.iat[4,1]
#             df.iat[5,current_col_index] = selected_ratio.iat[5,current_col_index] - selected_ratio.iat[5,1]
#             df.iat[6,current_col_index] = selected_ratio.iat[6,current_col_index] - selected_ratio.iat[6,1]
#             for i in range(len(selected_ratio)):
#                 pD.iat[0,current_col_index] += df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1]
#             pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
#         return df,pD    
#     if model == "Oil and Gas":
#         for current_col_index in range(1, 2050 - int(reporting_year) + 3):
#             df.iat[0,current_col_index] = selected_ratio.iat[0,current_col_index] - selected_ratio.iat[0,1]
#             df.iat[1,current_col_index] = selected_ratio.iat[1,current_col_index] - selected_ratio.iat[1,1]
#             df.iat[2,current_col_index] = selected_ratio.iat[2,current_col_index] - selected_ratio.iat[2,1]
#             df.iat[3,current_col_index] = selected_ratio.iat[3,current_col_index] - selected_ratio.iat[3,1]
#             for i in range(len(selected_ratio)):
#                 pD.iat[0,current_col_index] += df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1]
#             pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
#         return df,pD    
#     if model == "Metals & Mining":
#         for current_col_index in range(1 , 2050 - int(reporting_year)+3):
#             df.iat[0,current_col_index] = selected_ratio.iat[0,current_col_index] - selected_ratio.iat[0,1]
#             df.iat[1,current_col_index] = selected_ratio.iat[1,current_col_index] - selected_ratio.iat[1,1]
#             df.iat[2,current_col_index] = selected_ratio.iat[2,current_col_index] - selected_ratio.iat[2,1]
#             df.iat[3,current_col_index] = selected_ratio.iat[3,current_col_index] - selected_ratio.iat[3,1]
#             df.iat[4,current_col_index] = selected_ratio.iat[4,current_col_index] - selected_ratio.iat[4,1]
#             df.iat[5,current_col_index] = selected_ratio.iat[5,current_col_index] - selected_ratio.iat[5,1]
#             for i in range(len(selected_ratio)):
#                 pD.iat[0,current_col_index] += df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1]
#             pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
#         return df,pD

#     if model == "Infrastructure":
#         for current_col_index in range(1 , 2050 - int(reporting_year) +3):
#             df.iat[0,current_col_index] = selected_ratio.iat[0,current_col_index] - selected_ratio.iat[0,1]
#             df.iat[1,current_col_index] = selected_ratio.iat[1,current_col_index] - selected_ratio.iat[1,1]
#             df.iat[2,current_col_index] = selected_ratio.iat[2,current_col_index] - selected_ratio.iat[2,1]
#             df.iat[3,current_col_index] = selected_ratio.iat[3,current_col_index] - selected_ratio.iat[3,1]
#             df.iat[4,current_col_index] = selected_ratio.iat[4,current_col_index] - selected_ratio.iat[4,1]
#             for i in range(len(selected_ratio)):
#                 pD.iat[0,current_col_index] += (df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1])
#             pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
#         return df,pD
#     if model == "Chemical":
#         for current_col_index in range(1 , 2050 - int(reporting_year) + 3):
#             df.iat[0,current_col_index] = selected_ratio.iat[0,current_col_index] - selected_ratio.iat[0,1]
#             df.iat[1,current_col_index] = selected_ratio.iat[1,current_col_index] - selected_ratio.iat[1,1]
#             df.iat[2,current_col_index] = selected_ratio.iat[2,current_col_index] - selected_ratio.iat[2,1]
#             df.iat[3,current_col_index] = selected_ratio.iat[3,current_col_index] - selected_ratio.iat[3,1]
#             df.iat[4,current_col_index] = selected_ratio.iat[4,current_col_index] - selected_ratio.iat[4,1]
#             df.iat[5,current_col_index] = selected_ratio.iat[5,current_col_index] - selected_ratio.iat[5,1]
#             for i in range(len(selected_ratio)):
#                 pD.iat[0,current_col_index] += df.iat[i,current_col_index] * static_param_sector_model_df.iat[i,1]
#             pD.iat[0,current_col_index] = min((rating*m.exp(pD.iat[0,current_col_index])) ,1)
#         return df,pD
    
            
    