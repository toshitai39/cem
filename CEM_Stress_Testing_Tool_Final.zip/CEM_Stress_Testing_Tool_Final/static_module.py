# -*- coding: utf-8 -*-
"""
Created on Tue May 14 11:27:26 2024

@author: pkumar11
"""



## create_new_static_input creating new DataFrame with yearly columns added
def create_new_static_input(df):
    import pandas as pd
    import numpy as np
    
    other_column = list(df.columns)[:5]
    year_range = list(df.columns)[5:]
    yearly_column = list(np.arange(int(min(year_range)),int(max(year_range))+1))
    yearly=[]
    for i in yearly_column:
        yearly.append(str(i))

    new_column = other_column + yearly
    new_df = pd.DataFrame(columns= new_column)
    new_df[other_column] = df[other_column].copy()
    new_df[year_range] = df[year_range].copy()
    
    return new_df



## create_new_data_point function will perform interpolation
def create_new_data_point(df, reporting_year):
    for col in df:
        if col in df.columns[5:]:
            if int(col)%5 ==0:
                pass
            else:
                mod =  int(col)%5
                previous = int(col) - mod
                nxt = int(col) + (5-mod)
                df[col] = (df[str(nxt)] - df[str(previous)])/5 + df[str(int(col)-1)]
    col_lis = []

    for i in df.columns[5:]:
        if int(i) >= int(reporting_year-1):
            col_lis.append(i)

    col_list1 = list(df.columns[0:5]) + col_lis
    df = df[col_list1]
    return df  

