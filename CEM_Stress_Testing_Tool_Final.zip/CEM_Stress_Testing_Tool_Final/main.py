# -*- coding: utf-8 -*-
"""
Created on Tue May 14 11:15:15 2024

@author: pkumar11
"""

import pandas as pd
import numpy as np
import static_module as sm
import input_data_consolidated as idc
import input_tables as it
import result_module as rm
import res as res
from pandas import ExcelWriter
import warnings
warnings.filterwarnings("ignore")

# Reading source file/ Input file path
file = r'C:\Users\pkumar11\Downloads\Final\Copy of CEM Tool Input File for UBI POC_main.xlsx'

# Accesing diffrent tables from Static Input Sheet
static_df = pd.read_excel(file, sheet_name ='Static Input')

## Reading Dynamic Input sheet
dynamic_df = pd.read_excel(file, sheet_name ='Dynamic Input')


# User Input
Company_name = 'Coal India Limited'


reporting_year = dynamic_df[dynamic_df.Company == Company_name].Reporting_Year
reporting_end_year = 2050


df_list = np.split(static_df, static_df[static_df.isnull().all(1)].index)

def create_df(df, reporting_year):
    df = sm.create_new_static_input(df)
    df1 = sm.create_new_data_point(df, reporting_year)
    return df1

# Creation of DataFrame for India scenarios
firm_df = create_df(df_list[0],reporting_year)

# Creation of DataFrame for India scenarios
market_df = df_list[1].dropna(how='all')[1:].reset_index().drop("index", axis=1)
market_df = create_df(market_df,reporting_year)

## Creation of Conslodiated table based on Company Name



consolidated_df = idc.create_company_consolidated(dynamic_df,Company_name)

# Reading Model Input sheet
model_df = pd.read_excel(file , sheet_name = 'Model Input' , skiprows=1)

# ## Creation of Steel Model table based on Company Name
# steel_model_df = idc.creation_steel_model(model_df, Company_name)

sector_model = idc.sector_model(model_df, Company_name,dynamic_df)
#sum = sector_model['Scaled Weights'].sum()
## Creation of Emission table based on Company Name
emission_df = idc.creation_ghg_emission(dynamic_df, Company_name, consolidated_df )


#Other variables
Fitch_rating = idc.fitch_rating(model_df, Company_name)


TCO2E_USD_M = dynamic_df[dynamic_df["Company"] == Company_name].iloc[0]["Market_Carbon_Intensity_1_2"]
Euro_Dollar = dynamic_df[dynamic_df["Company"] == Company_name].iloc[0]["Euro_To_Dollar"]


#  Market Carbon Intensity Scope 1 or 2
market_carbon_intensity_scope12 = it.market_carbon_intensity_scope12(dynamic_df , Company_name)

# Market Carbon Intensity Scope 3
market_carbon_intensity_scope3 = it.market_carbon_intensity_scope3(dynamic_df , Company_name)

#  Firm Carbon Intensity Scope 1 or 2
firm_carbon_intensity_scope12 = it.firm_carbon_intensity_scope12(dynamic_df , Company_name)

# Firm Carbon Intensity Scope 3
firm_carbon_intensity_scope3 = it.firm_carbon_intensity_scope3(dynamic_df , Company_name)

# Market Carbon Reduction 
market_carbon_reduction_scope12 = it.market_carbon_reduction(market_df , int(reporting_year))


# Market Carbon Reduction
market_carbon_reduction_scope3 = it.market_carbon_reduction(market_df, int(reporting_year))

# Firm Carbon Reduction
firm_carbon_reduction_scope12 = it.firm_carbon_reduction(firm_df , int(reporting_year))

# Firm Carbon Reduction
firm_carbon_reduction_scope3 = it.firm_carbon_reduction(firm_df , int(reporting_year))

# distance_default_parameter in million USD

distance_default_parameter_df = it.distance_default_param(consolidated_df)

# elasticity_parameter 

elasticity_parameter_df = it.elasticity_static_param(dynamic_df ,consolidated_df , Company_name)


    
    
'''
The result sheet is starting from here.

'''   


# Creation of Static Parameters table from result sheet
static_parameter_result_df = rm.create_static_parameter_result_df(elasticity_parameter_df, dynamic_df, Company_name, "Base")


count = 0
for scenario in (list(firm_df.Scenario)[::-1] + ["Base"]):
    if scenario == "Low demand":
        pass
    else:
        # Creation of Input Parameters table from result sheet
        input_parms = res.input_parms(market_carbon_intensity_scope12 , market_carbon_intensity_scope3 , firm_carbon_intensity_scope12 , firm_carbon_intensity_scope3 , market_carbon_reduction_scope12 , market_carbon_reduction_scope3 , firm_carbon_reduction_scope12 , firm_carbon_reduction_scope3 , scenario)    

        # static_parameter_2
        # static_parameter_result_df2 = rm.static_parms(steel_model_df)
        # PD
        PD = rm.PD()
        # initial_rating
        initial_rating = rm.rating_PD(Fitch_rating , PD)
            


        # Creation of Algorithm table from the result sheet
        algorithm_result_df = rm.create_algorithm_df(input_parms, static_parameter_result_df, consolidated_df, reporting_year, reporting_end_year)



        # Creation of "P&L / CF / BS ($ millions)" and "Static Parameters" DFs 
        PL_CF_and_Static_param_tup = rm.create_pl_cf_static_param_df(input_parms, distance_default_parameter_df,consolidated_df, dynamic_df,algorithm_result_df, Company_name, reporting_year, reporting_end_year)

        PL_CF_BS_Mil_df = PL_CF_and_Static_param_tup[0]

        static_paramater_P_L = PL_CF_and_Static_param_tup[1]


        #  ************** Ratios DF

        ratios_df = rm.create_ratios_df(PL_CF_BS_Mil_df, reporting_year)

        #  ************* Normalized_Ratio DF

        normalized_ratios_df = rm.create_normalized_ratio_df(ratios_df)

        #  *********** Selected Ratios
        selected_ratio = rm.create_selected_ratios_df(normalized_ratios_df, sector_model)

        #   ***********  Static Parameter using Sector Model

        static_param_sector_model_df = rm.create_selected_static_param_df(sector_model)
        delta = rm.delta_scroes(model_df , selected_ratio , Company_name ,reporting_year , initial_rating ,static_param_sector_model_df)
 
        delta = rm.delta_scroes(model_df , selected_ratio , Company_name ,reporting_year , initial_rating ,static_param_sector_model_df)
 
        delta_calculated = delta[0]
        PD_calculated = delta[1] 
        
        
        if count==0:
            final_revenue_df = rm.func1(PL_CF_BS_Mil_df, scenario,"P&L – Revenues", reporting_year, reporting_end_year)
        else:
            final_revenue_df = rm.func2(PL_CF_BS_Mil_df, final_revenue_df, scenario,"P&L – Revenues")
          
        if count==0:
           final_ebita_df= rm.func1(PL_CF_BS_Mil_df, scenario, "P&L – EBITDA",reporting_year, reporting_end_year)
        else:
           final_ebita_df = rm.func2(PL_CF_BS_Mil_df, final_ebita_df, scenario, "P&L – EBITDA")           
        
        if count==0:
           final_ebit_df= rm.func1(PL_CF_BS_Mil_df, scenario, "P&L – EBIT", reporting_year, reporting_end_year)
        else:
           final_ebit_df = rm.func2(PL_CF_BS_Mil_df, final_ebit_df, scenario, "P&L – EBIT")           
        
        if count==0:
           final_Int_exp_df= rm.func1(PL_CF_BS_Mil_df, scenario, "P&L – Interest Expenses", reporting_year, reporting_end_year)
        else:
           final_Int_exp_df = rm.func2(PL_CF_BS_Mil_df, final_Int_exp_df, scenario, "P&L – Interest Expenses")           
        
        if count==0:
           final_T_debt_df= rm.func1(PL_CF_BS_Mil_df, scenario, "BS – Total Debt", reporting_year, reporting_end_year)
        else:
           final_T_debt_df = rm.func2(PL_CF_BS_Mil_df, final_T_debt_df, scenario, "BS – Total Debt")  
           
        if count==0:
           final_Book_cap_df= rm.func1(PL_CF_BS_Mil_df, scenario, "BS – Book Capitalization", reporting_year, reporting_end_year)
        else:
           final_Book_cap_df = rm.func2(PL_CF_BS_Mil_df, final_Book_cap_df, scenario, "BS – Book Capitalization")  
        
        if count==0:
           final_Tang_assets_df= rm.func1(PL_CF_BS_Mil_df, scenario, "BS – Tangible Assets", reporting_year, reporting_end_year)
        else:
           final_Tang_assets_df = rm.func2(PL_CF_BS_Mil_df, final_Tang_assets_df, scenario, "BS – Tangible Assets")  
          
        if count==0:
           final_CF_Divid_df= rm.func1(PL_CF_BS_Mil_df, scenario, "CF – Dividends", reporting_year, reporting_end_year)
        else:
           final_CF_Divid_df = rm.func2(PL_CF_BS_Mil_df, final_CF_Divid_df, scenario, "CF – Dividends")  

        if count== 0:
           final_PD_df = rm.delta_func1(PD_calculated , reporting_year , reporting_end_year , scenario)
        else:
            final_PD_df = rm.delta_func2(PD_calculated , final_PD_df, scenario)
         
        count = count+1
        
        
final_revenue_df.drop("Base_Implied", axis = 1, inplace=True)
final_revenue_df.drop("Parameters", axis = 1, inplace=True)
scenario_column1 = final_revenue_df.pop('Scenario')
final_revenue_df.insert(0, 'Scenario', scenario_column1)
final_revenue_df.reset_index(drop=True, inplace=True)

final_ebita_df.drop("Base_Implied", axis = 1, inplace=True)
final_ebita_df.drop("Parameters", axis = 1, inplace=True)
scenario_column2 = final_ebita_df.pop('Scenario')
final_ebita_df.insert(0, 'Scenario', scenario_column2)
final_ebita_df.reset_index(drop=True, inplace=True)

final_ebit_df.drop("Base_Implied", axis = 1, inplace=True)
final_ebit_df.drop("Parameters", axis = 1, inplace=True)
scenario_column3 = final_ebit_df.pop('Scenario')
final_ebit_df.insert(0, 'Scenario', scenario_column3)
final_ebit_df.reset_index(drop=True, inplace=True)

final_Int_exp_df.drop("Base_Implied", axis = 1, inplace=True)
final_Int_exp_df.drop("Parameters", axis = 1, inplace=True)
scenario_column4 = final_Int_exp_df.pop('Scenario')
final_Int_exp_df.insert(0, 'Scenario', scenario_column4)
final_Int_exp_df.reset_index(drop=True, inplace=True)

final_T_debt_df.drop("Base_Implied", axis = 1, inplace=True)
final_T_debt_df.drop("Parameters", axis = 1, inplace=True)
scenario_column5 = final_T_debt_df.pop('Scenario')
final_T_debt_df.insert(0, 'Scenario', scenario_column5)
final_T_debt_df.reset_index(drop=True, inplace=True)

final_Book_cap_df.drop("Base_Implied", axis = 1, inplace=True)
final_Book_cap_df.drop("Parameters", axis = 1, inplace=True)
scenario_column6 = final_Book_cap_df.pop('Scenario')
final_Book_cap_df.insert(0, 'Scenario', scenario_column6)
final_Book_cap_df.reset_index(drop=True, inplace=True)

final_Tang_assets_df.drop("Base_Implied", axis = 1, inplace=True)
final_Tang_assets_df.drop("Parameters", axis = 1, inplace=True)
scenario_column7 = final_Tang_assets_df.pop('Scenario')
final_Tang_assets_df.insert(0, 'Scenario', scenario_column7)
final_Tang_assets_df.reset_index(drop=True, inplace=True)

final_CF_Divid_df.drop("Base_Implied", axis = 1, inplace=True)
final_CF_Divid_df.drop("Parameters", axis = 1, inplace=True)
scenario_column8 = final_CF_Divid_df.pop('Scenario')
final_CF_Divid_df.insert(0, 'Scenario', scenario_column8)
final_CF_Divid_df.reset_index(drop=True, inplace=True)

        
final_PD_df.drop("Attribute", axis = 1, inplace=True)
scenario_column = final_PD_df.pop('Scenario')
final_PD_df.insert(0, 'Scenario', scenario_column)
final_PD_df.reset_index(drop=True, inplace=True)     




with ExcelWriter('cem_tool_output.xlsx') as writer:
    final_PD_df.to_excel(writer, sheet_name ="final_PD_df")
    final_revenue_df.to_excel(writer, sheet_name ="final_revenue_df")
    final_ebita_df.to_excel(writer, sheet_name ="final_ebita_df")
    final_ebit_df.to_excel(writer, sheet_name ="final_ebit_df")
    final_Int_exp_df.to_excel(writer, sheet_name ="final_Int_exp_df")
    final_T_debt_df.to_excel(writer, sheet_name ="final_T_debt_df")
    final_Book_cap_df.to_excel(writer, sheet_name ="final_Book_cap_df")
    final_Tang_assets_df.to_excel(writer, sheet_name ="final_Tang_assets_df")
    final_CF_Divid_df.to_excel(writer, sheet_name ="final_CF_Divid_df")
    
    
    
    





    


        


