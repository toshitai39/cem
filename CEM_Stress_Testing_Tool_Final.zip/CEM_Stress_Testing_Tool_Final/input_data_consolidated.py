# -*- coding: utf-8 -*-
"""
Created on Tue May 14 14:30:53 2024

@author: pkumar11
"""

## Function to create Consolidated table with million and million_usd conversion - - Input Data Sheet
def create_company_consolidated(dynamic_df,Company_name):
    import pandas as pd
    import numpy as np
    # creating a list of column required for consolidated table as per excel sheet
    #consolidate_columns = ['Exchange Rate','Tax Rate','P&L – Revenues','P&L – EBITDA','P&L – EBITA',
    #                       'P&L – EBIT','P&L – Interest Expenses','CF – Dividends','CF – Capital Expenditure',
     #                      'BS – Equity','BS – Total Assets','BS – Cash','BS – Book Capitalization',
      #                     'BS – Marketable Securities','PAT','Total Revenue','Firm Profit']
    
    consolidate_columns = ['Exchange_Rate','Tax_Rate','P_L_Revenues','P_L_EBITDA','P_L_EBITA','P_L_EBIT',
                            'P_L_Interest_Expenses','CF_Dividends','CF_Capital_Expenditure','BS_Equity',
                            'BS_Total_Assets','BS_Cash','BS_Book_Capitalization','BS_Marketable_Securities',
                            'PAT','Total_Revenue','Firm_Profit']

    consolidate_df = pd.DataFrame()  
    #Filtering the rows for specific company_name and copying all columns from consolidate_columns
    consolidate_df = dynamic_df[dynamic_df["Company"] == Company_name]

    consolidate_df = consolidate_df[consolidate_columns ].copy()
    id = consolidate_df.index[0]
    #Transposing the dataframe to acheive same structure as per the excel sheet
    consolidate_df_T = consolidate_df.T.reset_index()
    consolidate_df_T.rename(columns = {"index" : "attribute", id : "Value"},inplace = True)
        
    #Updating value for "Firm PRofit" as PAT/Total Revenue
    consolidate_df_T.iat[16,1]= consolidate_df_T.iat[14,1] / consolidate_df_T.iat[15,1]

    #Creation of new column "In_Million_INR" using formula original_value * 10
    consolidate_df_T["In_Million_INR"] = consolidate_df_T["Value"]*1

    #Creation of new column "In_Million_USD" using formula "In_Million_INR"/Exchange Rate
    consolidate_df_T["In_Million_USD"] = consolidate_df_T["In_Million_INR"]/consolidate_df_T.iat[0,1]

    #Appending a row to have Company Name for future purpose to identify this dataframe
    consolidate_df_T.loc[-1] = ["Company",Company_name, np.nan,np.nan]    
    consolidate_df_T.index = consolidate_df_T.index +1
    consolidate_df_T.sort_index(inplace=True)
    
    return consolidate_df_T


# -*- coding: utf-8 -*-
"""
Created on Wed May 15 13:18:13 2024
 
@author: omkajadhav
"""
 

def create_multiple_df(df, header_name):
    import pandas as pd
 

# Define the header that marks the start of each table
    header = header_name # Replace "Your_Header_Text" with the actual header text
 
# Find the row indices where the header appears
    header_indices = df.index[df.eq(header).any(axis=1)].tolist()
 
# Initialize a list to store the DataFrames of each table
    tables = []
 
# Iterate over the header indices to split the DataFrame into tables
    for i, header_index in enumerate(header_indices):
        if i == len(header_indices) - 1:
            table_df = df.iloc[header_index:].reset_index(drop=True)
        else:
            next_header_index = header_indices[i+1]
            table_df = df.iloc[header_index:next_header_index].reset_index(drop=True)
    # Skip empty rows
        table_df = table_df.dropna(how='all')
    # Set the first row as the header
        table_df.columns = table_df.iloc[0]
    # Drop the first row after using it as the header
        table_df = table_df.drop(index=0).reset_index(drop=True)
    # Append the table to the list
        tables.append(table_df)
    return tables



"""
Created on Wed May 15 13:18:13 2024

@author: omkajadhav
"""

##Creation of GHG Emissions Table - Input Data Sheet
def creation_ghg_emission(dynamic_df, Company_name, consolidated_df):
    import pandas as pd
    #P&L – Revenues (In USD Millions (1 USD = 83.21 INR)) from Consolidated table 
    col = consolidated_df.columns[0]
    dynamic_df1 = dynamic_df[dynamic_df["Company"] == Company_name]
    col_required = ["Company","Scope_1_Emissions","Scope_2_Emissions","Scope_3"]
    id = dynamic_df1.index[0]
    dynamic_df2 = dynamic_df1[col_required].copy()
    dynamic_df2_T = dynamic_df2.T.reset_index()
    dynamic_df2_T.rename(columns = {"index" : "attribute", id : "Value"},inplace = True)
    
    
    PL_Revenue_deno = list(consolidated_df[consolidated_df[col] == "P_L_Revenues"]["In_Million_INR"])
    PL_Revenue_deno = PL_Revenue_deno[0]
            
    # Select the relevant rows and columns for Beta_data_df
    GHG_data_df = dynamic_df2_T.loc[:]
    # Calculate the "Firm Intensity (Scope 1/2)" column
    GHG_data_df["Firm Intensity (Scope 1/2)"] = ((GHG_data_df.loc[1,"Value"]+GHG_data_df.loc[2,"Value"])/PL_Revenue_deno)
    # Calculate the "Firm Intensity (Scope 3)" column
    GHG_data_df["Firm Intensity (Scope 3)"] = ((GHG_data_df.loc[3,"Value"]) /PL_Revenue_deno)
    
    return GHG_data_df



###creation of Steel Model- Moody's Table - - Input Data Sheet

def sector_model(model_df , Company_name , dynamic_df):
    import pandas as pd
    model_df.set_index('Id', inplace=True)
    beta_df = pd.DataFrame()  
    beta_df = model_df[model_df["Company"] == Company_name]
    model = beta_df["Model"].values[0]
    id = beta_df.index[0]

    if model == 'Steel':
        columns_beta_df = ["Revenues","EBIT_Revenues" ,"EBIT_Tangible_Assets","Debt_EBITDA",
                        "Debt_Book_Capitalization","CFO_Dividends_Debt","EBIT_Interest_Expenses"]
        steel = beta_df[columns_beta_df].copy()
        steel_T = steel.T.reset_index()
        steel_T.rename(columns = {0 : "attribute", id : "Value"},inplace = True)
        length = len(columns_beta_df)
        
        pd_sum = steel_T["Value"].iloc[1:7].sum()
        denominator = steel_T.loc[0,"Value"] + pd_sum
        Scaling_fact = 1 - denominator
        steel_T["factors Weight"] = ((steel_T["Value"] / denominator) * Scaling_fact)
        steel_T["Scaled Weights"] = (steel_T["Value"] + steel_T["factors Weight"])
        return steel_T
    if model == 'Cement':
        columns_beta_df = ['Revenues','Debt_EBITDA','Debt_Book_Capitalization' , 'EBIT_Interest_Expenses',
                       'RCF_Net_Debt' , 'EBIT_Revenues' , 'EBIT_Assets']

        cement = beta_df[columns_beta_df].copy()
        cement_T = cement.T.reset_index()
        cement_T.rename(columns = {0 : "attribute", id : "Value"},inplace = True)
        length = len(columns_beta_df)

        pd_sum = cement_T["Value"].iloc[0:7].sum()
        Scaling_fact = 1 - pd_sum
        cement_T["factors Weight"] = ((cement_T["Value"] / pd_sum) * Scaling_fact)
        cement_T["Scaled Weights"] = (cement_T["Value"] + cement_T["factors Weight"])
        return cement_T
    
    if model == 'Chemical':
        columns_beta_df = ['Revenues','Debt_EBITDA' , 'RCF_Net_Debt', 
                       'EBITDA_Revenues' , 'EBIT_Assets' , 'EBITDA_Interest_Expenses']
        
        chemical = beta_df[columns_beta_df].copy()
        chemical_T = chemical.T.reset_index()
        chemical_T.rename(columns = {0 : "attribute", id : "Value"},inplace = True)
        length = len(columns_beta_df)

        pd_sum = chemical_T["Value"].iloc[0:6].sum()
        Scaling_fact = 1 - pd_sum
        chemical_T["factors Weight"] = ((chemical_T["Value"] / pd_sum) * Scaling_fact)
        chemical_T["Scaled Weights"] = (chemical_T["Value"] + chemical_T["factors Weight"])
        return chemical_T   
    
    if model == 'Metals & Mining':
        columns_beta_df = ['Revenues' , 'EBIT_Revenues' , 'Debt_EBITDA'
                       ,'Debt_Book_Capitalization' , 'CFO_Dividends_Debt'
                       ,'EBIT_Interest_Expenses']
        
        metals_mining = beta_df[columns_beta_df].copy()
        metals_mining_T = metals_mining.T.reset_index()
        metals_mining_T.rename(columns = {0 : "attribute", id : "Value"},inplace = True)
        length = len(columns_beta_df)

        pd_sum = metals_mining_T["Value"].iloc[0:6].sum()
        Scaling_fact = 1 - pd_sum
        metals_mining_T["factors Weight"] = ((metals_mining_T["Value"] / pd_sum) * Scaling_fact)
        metals_mining_T["Scaled Weights"] = (metals_mining_T["Value"] + metals_mining_T["factors Weight"])
        return metals_mining_T
   
    if model == 'Oil and Gas':
        columns_beta_df = ['Debt_Book_Capitalization' , 'EBIT_Interest_Expenses' ,
                       'EBIT_Book_Capitalization' , 'RCF_Net_Debt']
        
        oil_gas = beta_df[columns_beta_df].copy()
        
        oil_gas_T = oil_gas.T.reset_index()
        oil_gas_T.rename(columns = {0 : "attribute", id : "Value"},inplace = True)
        length = len(columns_beta_df)

        pd_sum = oil_gas_T["Value"].iloc[1:4].sum()
        denominator = oil_gas_T.loc[0,"Value"] + pd_sum
        Scaling_fact = 1 - denominator
        oil_gas_T["factors Weight"] = ((oil_gas_T["Value"] / denominator) * Scaling_fact)
        oil_gas_T["Scaled Weights"] = (oil_gas_T["Value"] + oil_gas_T["factors Weight"])
        return oil_gas_T
    
    if model == 'Infrastructure':
        columns_beta_df = ['Revenues' , 'Debt_EBITDA' , 'EBIT_Interest_Expenses'
                       , 'EBITDA' , 'FCF_Debt']
        
        infrastructure = beta_df[columns_beta_df].copy()

        infrastructure_T = infrastructure.T.reset_index()
        infrastructure_T.rename(columns = {0 : "attribute", id : "Value"},inplace = True)
        length = len(columns_beta_df)

        pd_sum = infrastructure_T["Value"].iloc[1:5].sum()
        denominator = infrastructure_T.loc[0,"Value"] + pd_sum
        Scaling_fact = 1 - denominator
        infrastructure_T["factors Weight"] = ((infrastructure_T["Value"] / denominator) * Scaling_fact)
        infrastructure_T["Scaled Weights"] = (infrastructure_T["Value"] + infrastructure_T["factors Weight"])
        return infrastructure_T
    if model == 'Textile':
        columns_beta_df = ['Revenues' , 'Debt_EBITDA' ,'RCF_Net_Debt'
                       , 'EBITDA_Interest_Expenses' ]
        
        textile = beta_df[columns_beta_df].copy()

        textile_T = textile.T.reset_index()
        textile_T.rename(columns = {0 : "attribute", id : "Value"},inplace = True)
        length = len(columns_beta_df)

        pd_sum = textile_T["Value"].iloc[1:4].sum()
        denominator = textile_T.loc[0,"Value"] + pd_sum
        Scaling_fact = 1 - denominator
        textile_T["factors Weight"] = ((textile_T["Value"] / denominator) * Scaling_fact)
        textile_T["Scaled Weights"] = (textile_T["Value"] + textile_T["factors Weight"])
        return textile_T

def fitch_rating(model_df , Company_name):
    company_data = model_df[model_df['Company'] == Company_name]
    if company_data.empty:
        raise ValueError(f"Company '{Company_name}' not found in the dataframe.")
    rating = company_data[ 'Fitch_Issuer_Default _Rating'].iloc[0] 

    return rating

