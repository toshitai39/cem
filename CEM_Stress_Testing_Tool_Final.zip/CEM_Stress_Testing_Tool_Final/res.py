import pandas as pd
import numpy


def input_parms(market_carbon_intensity_scope12 , market_carbon_intensity_scope3 , firm_carbon_intensity_scope12 , firm_carbon_intensity_scope3 , market_carbon_reduction_scope12 , market_carbon_reduction_scope3 , firm_carbon_reduction_scope12 , firm_carbon_reduction_scope3 , scenario ):
    market_carbon_reduction_scope12.set_index("Scenario", inplace = True)
    market_carbon_reduction_scope3.set_index("Scenario", inplace = True)
    firm_carbon_reduction_scope12.set_index("Scenario", inplace = True)
    firm_carbon_reduction_scope3.set_index("Scenario", inplace = True)
    market_carbon_intensity_scope12_va = market_carbon_intensity_scope12.loc[scenario]
    market_carbon_intensity_scope3_va = market_carbon_intensity_scope3.loc[scenario]
    firm_carbon_intensity_scope12_va = firm_carbon_intensity_scope12.loc[scenario]
    firm_carbon_intensity_scope3_va = firm_carbon_intensity_scope3.loc[scenario]
    market_carbon_reduction_scope12_va = market_carbon_reduction_scope12.loc[scenario]
    market_carbon_reduction_scope3_va = market_carbon_reduction_scope3.loc[scenario]
    firm_carbon_reduction_scope12_va = firm_carbon_reduction_scope12.loc[scenario]
    firm_carbon_reduction_scope3_va = firm_carbon_reduction_scope3.loc[scenario]
    market_carbon_reduction_scope12_va.index = market_carbon_intensity_scope12_va.index
    market_carbon_reduction_scope3_va.index = market_carbon_intensity_scope3_va.index
    firm_carbon_reduction_scope12_va.index = firm_carbon_intensity_scope12_va.index
    firm_carbon_reduction_scope3_va.index = firm_carbon_intensity_scope3_va.index
    data = {
    'Input Parameters': [
        'Market Carbon Intensity (Scope 1/2)', 
        'Market Carbon Intensity (Scope 3)', 
        'Firm Carbon Intensity (Scope 1/2)',
        'Firm Carbon Intensity (Scope 3)' , 
        'Market Carbon Reduction (Scope 1/2)' , 
        'Market Carbon Reduction (Scope 3)' ,
        'Firm Carbon Reduction (Scope 1/2)' ,
        'Firm Carbon Reduction (Scope 3)' ,
        'Scenario Carbon Price' , 
        'Scenario Carbon Price (Market)'

    ],
    'Scenario': [scenario, scenario, scenario , scenario , scenario , scenario , scenario , scenario , scenario , scenario],
    }
    years = market_carbon_intensity_scope12_va.index
    for year in years:
        data[year] = [
            market_carbon_intensity_scope12_va[year], 
            market_carbon_intensity_scope3_va[year], 
            firm_carbon_intensity_scope12_va[year]
            , firm_carbon_intensity_scope3_va[year]
            , market_carbon_reduction_scope12_va[year]
            , market_carbon_reduction_scope3_va[year]
            , firm_carbon_reduction_scope12_va[year]
            , firm_carbon_reduction_scope3_va[year]
            , firm_carbon_reduction_scope12_va[year]
            , market_carbon_reduction_scope12_va[year]
        ]
    result_df = pd.DataFrame(data)
    
    market_carbon_reduction_scope12.reset_index(inplace = True)
    market_carbon_reduction_scope3.reset_index(inplace = True)
    firm_carbon_reduction_scope12.reset_index(inplace = True)
    firm_carbon_reduction_scope3.reset_index(inplace = True)

    return result_df