import pandas as pd
import numpy as np

# genric function to generate intensity data
def generate_intensity_data(start_year, end_year, initial_intensity, num_years):
    data = {year: ((end_year - year) * initial_intensity) / num_years for year in range(start_year, end_year + 1)}
    return data

# function to generate market carbon intensity for scope 1 or 2 for a company
def market_carbon_intensity_scope12(dynamic_df, Company_name):
    # checking if the company name given in the input is present in the dataframe``
    company_data = dynamic_df[dynamic_df['Company'] == Company_name]
    if company_data.empty:
        raise ValueError(f"Company '{Company_name}' not found in the dataframe.")


    intensities = company_data.iloc[0]['Market_Carbon_Intensity_1_2']
    start_year = company_data.iloc[0]['Reporting_Year']-1
    dif = 2050 - int(start_year) 
    Scenario = ["Base", "Below 2°C", "Current Policies", "Delayed transition", "Fragmented World", "Nationally Determined Contributions (NDCs)", "Net Zero 2050"]
    data = {scenario: generate_intensity_data(int(start_year), 2050, intensities ,dif) for scenario in Scenario}  
    df = pd.concat({k: pd.Series(v) for k, v in data.items()}, axis=1)
    df.reset_index(inplace=True)
    df.rename(columns={'index': 'Year'}, inplace=True)
    df.set_index('Year', inplace=True)

    return df.T

# function to generate market carbon intensity for scope 3 for a company 
def market_carbon_intensity_scope3(dynamic_df, Company_name):
    # checking if the company name given in the input is present in the dataframe
    company_data = dynamic_df[dynamic_df['Company'] == Company_name]
    if company_data.empty:
        raise ValueError(f"Company '{Company_name}' not found in the dataframe.")
    
    intensities = company_data.iloc[0]['Market_Carbon_Intensity_Scope_3']
    start_year = company_data.iloc[0]['Reporting_Year']-1
    dif = 2050 - int(start_year)   
    Scenario = ["Base", "Below 2°C", "Current Policies", "Delayed transition", "Fragmented World", "Nationally Determined Contributions (NDCs)", "Net Zero 2050"]
    data = {scenario: generate_intensity_data(int(start_year), 2050, intensities ,dif) for scenario in Scenario}  
    df = pd.concat({k: pd.Series(v) for k, v in data.items()}, axis=1)
    df.reset_index(inplace=True)
    df.rename(columns={'index': 'Year'}, inplace=True)
    df.set_index('Year', inplace=True)
    return df.T


# function to generate firm carbon intensity for scope 1 or 2 for a company 
def firm_carbon_intensity_scope12(dynamic_df, Company_name):
    company_data = dynamic_df[dynamic_df['Company'] == Company_name]
    if company_data.empty:
        raise ValueError(f"Company '{Company_name}' not found in the dataframe.")
    
    intensities = company_data.iloc[0]['Firm_Carbon_Intensity_Scope_1_2']  
    start_year = company_data.iloc[0]['Reporting_Year']-1
    dif = 2050 - int(start_year) 
    Scenario = ["Base", "Below 2°C", "Current Policies", "Delayed transition", "Fragmented World", "Nationally Determined Contributions (NDCs)", "Net Zero 2050"]
    data = {scenario: generate_intensity_data(int(start_year), 2050, intensities ,dif) for scenario in Scenario}  
    df = pd.concat({k: pd.Series(v) for k, v in data.items()}, axis=1)
    df.reset_index(inplace=True)
    df.rename(columns={'index': 'Year'}, inplace=True)
    df.set_index('Year', inplace=True)
    return df.T


# function to generate firm carbon intensity for scope 3 for a company   
def firm_carbon_intensity_scope3(dynamic_df, Company_name):
    company_data = dynamic_df[dynamic_df['Company'] == Company_name]
    if company_data.empty:
        raise ValueError(f"Company '{Company_name}' not found in the dataframe.")
    
    intensities = company_data.iloc[0]['Firm_Carbon_Intensity_Scope_3']  
    start_year = company_data.iloc[0]['Reporting_Year']-1
    dif = 2050 - int(start_year) 
    Scenario = ["Base", "Below 2°C", "Current Policies", "Delayed transition", "Fragmented World", "Nationally Determined Contributions (NDCs)", "Net Zero 2050"]
    data = {scenario: generate_intensity_data(int(start_year), 2050, intensities ,dif) for scenario in Scenario}  
    df = pd.concat({k: pd.Series(v) for k, v in data.items()}, axis=1)
    df.reset_index(inplace=True)
    df.rename(columns={'index': 'Year'}, inplace=True)
    df.set_index('Year', inplace=True)
    return df.T


def market_carbon_reduction(market_df , reporting_year):
    # first we are taking the first 36 columns of the static market data 
    alt = market_df
    dif = int(2050 - int(reporting_year)+ 7)
    alt = alt.iloc[:,0:dif]
    alt.loc[7] = alt.loc[1]
    # adding base equal to the current policies and then making it as the first row as present in the excel
    alt.loc[7 ,'Scenario'] = 'Base'
    alt.drop(columns = ['Model','Region' , 'Variable' , 'Unit'], inplace = True)
    alt.loc[3 , 'Scenario'] = 'Fragmented World'
    alt.drop(4, inplace = True)
    alt.reset_index(drop = True, inplace = True)
    new_indices = [6] + list(range(0, 6)) + list(range(7, len(alt)))
    alt = alt.reindex(new_indices)
    alt.reset_index(drop = True, inplace = True)
    return alt

def firm_carbon_reduction(firm_df , reporting_year):
    # same things are done for the firm data
    alt = firm_df
    dif = int(2050 - int(reporting_year)+ 7)
    alt = alt.iloc[:,0:dif]
    alt.loc[7] = alt.loc[1]
    alt.loc[7 ,'Scenario'] = 'Base'
    alt.drop(columns = ['Model','Region' , 'Variable' , 'Unit'], inplace = True)
    alt.loc[3 , 'Scenario'] = 'Fragmented World'
    alt.drop(4, inplace = True)
    alt.reset_index(drop = True, inplace = True)
    new_indices = [6] + list(range(0, 6)) + list(range(7, len(alt)))
    alt = alt.reindex(new_indices)
    alt.reset_index(drop = True, inplace = True)
    return alt

'''
This is the function for creating the dataframe of the distance default parameter with the placeholders 
present as nan values in the dataframe as mentioned in the excel sheet
'''

def distance_default_param(consolidated_df):
    d = consolidated_df.loc[3:14]
    d = d.drop(['Value','In_Million_INR'], axis=1)
    new_rows = pd.DataFrame({
    'attribute': ['Net_Income', 'Retained_Cash_Flow', 'Free_Cash_Flow' , 'Funds_from_Operations' ,'Cash_Flow_from_Operations' , 'Total_Debt' , 'Net_Debt', 'Tangible_Asset' ,'Opertaing_Income','Preferred_Stock' , 'Capitalized_interest' , 'Secured_Debt' , 'Depreciations' , 'Depreciations_and_Amortizations' ],
    'In_Million_USD': [np.nan, np.nan, np.nan, np.nan, np.nan , np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
    })

    d = pd.concat([d, new_rows], ignore_index=True)
    return d
'''
This is the function for creating the dataframe of the elasticity static parameter with the placeholders
present as nan values in the dataframe as mentioned in the excel sheet

'''
def elasticity_static_param(dynamic_df ,consolidated_df , Company_name):
    # checking if the company name given in the input is present in the dataframe
    company_data = dynamic_df[dynamic_df['Company'] == Company_name]
    # on company name we use the dynamic` dataframe to get the values of the company
    melted_df = pd.melt(company_data, 
                    id_vars=['Company'],
                    value_vars=['Price_Elasticity', 'Market_Cost_Elasticity', 'Firm_Cost_Elasticity', 
                                'Weight_Assets', 'Weight_Debt', 'Weight_Markov', 'Weight_What_If'],
                    var_name='Variable', value_name='Value')
    attribute = consolidated_df.loc[consolidated_df['attribute'] == 'Firm_Profit', 'attribute'].values[0]
    value = consolidated_df.loc[consolidated_df['attribute'] == 'Firm_Profit', 'Value'].values[0]
    new_row = {'Company': Company_name, 'Variable': attribute, 'Value': value}
    new_row_df = pd.DataFrame([new_row])
    melted_df = pd.concat([melted_df, new_row_df], ignore_index=True)

    return melted_df

